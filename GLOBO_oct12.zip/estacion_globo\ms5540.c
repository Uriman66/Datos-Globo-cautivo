//#include <18F252.h>
//#fuses HS,NOBROWNOUT,NOWDT,NOPUT,NOPROTECT,NOLVP
//#use delay(clock=10000000)
//#use i2c(master,sda=PIN_b6, scl=PIN_b7)
//#use rs232(baud=2400, xmit=PIN_b4, rcv=PIN_b5, bits=8,PARITY=o)
//
byte w1_l,w1_h,w2_l,w2_h,w3_l,w3_h,w4_l,w4_h;
unsigned long w1,w2,w3,w4,c1,c2,c3,c4,c5,c6,d1,d2;
signed int32 offst,sensitividad,xsensitividad,ut1,dt;
float temp_5540,presion;// en estas variables se guardan las lecturas
void letc_calc_5540(void);//Realiza lectura y calculo de presion
void reset_ms5540 (void);//realiza reset del dispositivo
void ini_ms5540(void);//realiza la inicializacion del dispositivo

void ini_ms5540(void)//Rutina de inicializaci�n del modulo ms5540
{       
        spi_write(0x15);//reset
        spi_write(0x55);//reset
        spi_write(0x40);//reset
        spi_write(0);
        spi_write(0x1D);//lectura palabra 1
        spi_write(0x50);//
        w1_h=spi_read(0);
        w1_l=spi_read(0);
        w1=make16(w1_h,w1_l);
        spi_write(0x1D);//lectura palabra 2
        spi_write(0x60);//
        w2_h=spi_read(0);
        w2_l=spi_read(0);
        w2=make16(w2_h,w2_l);
        spi_write(0x1D);//lectura palabra 3
        spi_write(0x90);//
        w3_h=spi_read(0);
        w3_l=spi_read(0);
        w3=make16(w3_h,w3_l);
        spi_write(0x1D);//lectura palabra 4
        spi_write(0xA0);//
       
        w4_h=spi_read(0);
        w4_l=spi_read(0);
        w4=make16(w4_h,w4_l);
        c1=w1>>1;
        c2=w3&0x003f;
        c2=c2<<6;
        c2=c2+(w4&0x003f);
        c3=w4>>6;
        c4=w3>>6;
        c5=w2;
        c5=c5>>6;
        if (bit_test(w1,0))
            {bit_set(c5,10);}
    
        c6=w2&0x003f;

}



void reset_ms5540 (void)//secuencia de reset
{       spi_write(0x15);
        spi_write(0x55);
        spi_write(0x40);
        
        }

void letc_calc_5540(void)
{
        
        spi_write(0x0f);//Lectura de d1
        spi_write(0x40);
        while(input(pin_c4));
   
        w1_h=spi_read(0);  
        w1_l=spi_read(0); 
        d1=make16(w1_h,w1_l);

        
        spi_write(0x0f);//Lectura de d2
        spi_write(0x20);
        while(input(pin_c4));

        w2_h=spi_read(0);  
        w2_l=spi_read(0); 
        d2=make16(w2_h,w2_l);
        
        ut1=(8*c5)+20224;
        
        dt=d2-ut1;
        
        temp_5540=200+((dT*(c6+50))/1024);
        
        offst=((c4-512)*dT)/4096;
        offst=(c2*4)+offst;
        sensitividad=(c3*dT);
        sensitividad=sensitividad/1024;
        sensitividad=c1+sensitividad+24576;
      
        xsensitividad=((sensitividad*(d1-7168))/16384)-offst;
        
        presion=(xsensitividad*.03125)+250;

}
//
//void main ()
//{
//                    
//
//
//                    delay_ms(200);
//                   
//                    output_float(pin_C3);
//                    output_float(pin_c4);
//                    output_low(pin_c5);
//
//                     i2c_start();
//                     i2c_write(0b11010000); //byte de control del reloj, con escritura
//                     i2c_write(8);//inicializando el puntero a la direccion 8
//                     i2c_stop();
//                           i2c_start();
//                           i2c_write(0b11010000);//byte de control del reloj, con escritura
//                           i2c_write(0);//inicializando el puntero a la direccion cero
//                           i2c_write(0);//Cofigura segundos e inicia el oscilador
//                           i2c_write(0);//Configura minutos
//                           i2c_write(0);//configura horas
//                           i2c_write(0);   //Dia de la semana
//                           i2c_write(1);   //Cofigura dia
//                           i2c_write(1);   //Configura mes
//                           i2c_write(1);   //Cofigura a�o
//                           i2c_write(0b00010011);   //Saca la se�al del oscilador a 1hz
//                           i2c_write(0x13);//bit q indica q la configuracion ha sido realizada
//                           i2c_stop();
//        //set_tris_c(0b00010010);
//        setup_spi(spi_master|SPI_L_TO_H|SPI_CLK_DIV_64|SPI_XMIT_L_TO_H|SPI_SAMPLE_AT_END);//configura spi
// 
//
//ini_ms5540();
////printf("%Lx %Lx %Lx %Lx",w1,w2,w3,w4);
////printf("%Lu %Lu %Lu %Lu %Lu %Lu ",c1,c2,c3,c4,c5,c6);
////delay_ms(100);
//while(1)
//    {
//        
//        reset_ms5540();
//        letc_calc_5540();
//    //    printf(" %Lu %Lu %Lu %Lu %Lu",ut1,dt,offst,sensitividad,xsensitividad);
//
//        printf(" Temperatura= %.1f C",temp_5540);
//        printf("Presion= %.1f mbar %Lu %Lu\n", presion,d2, d1);   
//        
//        delay_ms(1000);
//        
//    }
//}
//
