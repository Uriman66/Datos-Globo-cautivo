//#include <18F248.h>
//#fuses HS,NOBROWNOUT,NOWDT,NOPUT,NOPROTECT,NOLVP
//#use delay(clock=10000000)
////#include <lcd.c>
//#define habilitador pin_c2//se descomenta si se quiere utilizar el pin de habilitacion

#include <math.h>
#ifndef pin_sync
	#define pin_sync   pin_c1
#endif
#ifndef pin_calibracion
	#define pin_calibracion	pin_c0
#endif

#define xrawve 0x01
#define yrawve 0x02
#define xcalve 0x03
#define ycalve 0x04
#define headingve 0x05
#define magnitudeve 0x06
#define temp_v2xe 0x07
#define distortion 0x08
#define calstatus 0x09

//variables v2xe
float x_calibrado,y_calibrado;
//byte tempo1_v2xe,tempo2_v2xe,tempo3_v2xe,tempo4_v2xe;
float xoffset,yoffset,xgain,ygain;
signed int32 rawxv,rawyv;
//float phi,cal_magn;
int1 signox,signoy;
byte dato_v2xe;
byte en_ieee[4];
float direccion,magnitud;


//funcion ieee_en_mic()
//convierte en flotante de formato ieee en formato de microchip
//es necesario declarar la matriz: byte en_ieee[4] como global 
//se colocan los datos en dicha matriz antes de llamar la funci�n
//el byte mas significativo se coloca en la posicion 0
float ieee_en_mic()
{

int1 temp;
int32 flo;
float *pf;
   temp = shift_left(&en_ieee[1], 1, 0);
   temp = shift_left(&en_ieee[0], 1, temp);
   shift_right(&en_ieee[1], 1, temp);
   
   pf=&flo;
   flo=make32(en_ieee[3],en_ieee[2],en_ieee[1],en_ieee[0]);

   return(*pf);

}
float mic_en_ieee(float num_flotante)
{
int1 acarreo;

acarreo=shift_left(&num_flotante+1,1,0);
acarreo=shift_right(&num_flotante,1,acarreo);
shift_right(&num_flotante+1,1,acarreo);
return(num_flotante);
}




void lee_datos_v2xe(void)
{
   dato_v2xe=spi_read(0xaa);
   dato_v2xe=spi_read(0x04);//pide datos
   dato_v2xe=spi_read(0x00);
   delay_ms(5);
   while (dato_v2xe!=0xaa)//Espera q la v2xe envie datos
      dato_v2xe=spi_read(0x00);

   dato_v2xe= spi_read(0);//lee id de comando
   dato_v2xe= spi_read(0);//lee n comp
   dato_v2xe= spi_read(0);//lee id de dato5
   en_ieee[0]=spi_read(0x00);//lee dato3
   en_ieee[1]=spi_read(0x00);
   en_ieee[2]=spi_read(0x00);
   en_ieee[3]=spi_read(0x00);
   direccion=ieee_en_mic();//convierte de formato ieee a formato de microcip
   dato_v2xe= spi_read(0);//lee caracter de fin
}




void calcula_dir_v2xe(void)
{


y_calibrado=(rawyv+yoffset)*ygain;
x_calibrado=(rawxv+xoffset)*xgain;
if(y_calibrado<0)
        signoy=1;
else
        signoy=0;

if(x_calibrado<0)
        signox=1;
else
        signox=0;
direccion=abs(atan(y_calibrado/x_calibrado));
direccion=57.2958*direccion;
if(signox==1&&signoy==1)
        direccion=180-direccion;
if(signox==1&&signoy==0)
        direccion=180+direccion;
if(signox==0&&signoy==0)
        direccion=360-direccion;

}


//Realiza la calibraci�n de v2xe
//Se debe realizar la configuracion de la v2xe
//antes de llamar a esta funcion
void calibracion_1(void)
{
signed int32 maxX,maxY,minX,minY;
int1 salir;

maxX=-32768;
maxY=-32768;
minX=32767;
minY=32767;
salir=0;

	while(input(pin_calibracion));//Espera a que se presione
	delay_ms(100);                 //el bot�n para iniciar la 
	while(!input(pin_calibracion));//calibraci�n
        delay_ms(100);
        output_low(indicador);
        while(salir==0)
        {
        
        lee_datos_v2xe();
        if(rawxv>maxx)
                maxx=rawxv;
        if(rawxv<minx)
                minx=rawxv;
        if(rawyv>maxy)
                maxy=rawyv;
        if(rawyv<miny)
                miny=rawyv;
        
        if(!input(pin_calibracion))
                salir=1;
        }
        delay_ms(50);
        output_high(indicador);
        //while (!input(pin_calibracion));
        xoffset=((maxx-minx)/2)-maxx;
        xgain=2/(maxx-minx);
        yoffset=((maxy-miny)/2)-maxy;
        ygain=2/(maxy-miny);


}

//
void calibracion()
{
int temp;
char caracter_x;
	output_float(pin_calibracion);
	temp=spi_read(0xaa);
	temp=spi_read(0x06);//setconfig
	temp=spi_read(0x05);
	temp=spi_read(0x04);
	temp=spi_read(0x00);

//	while(input(pin_calibracion));//Espera a que se presione
//	delay_ms(50);                 //el bot�n para iniciar la 
//	while(!input(pin_calibracion));//calibraci�n
////	lcd_putc("\fIniciando Calibracion...");
        do
        {
        caracter_x=getc();
        }while(caracter_x!='F');
        delay_ms(100);
        output_low(indicador);
	temp=spi_read(0xaa);//envio comando starcal
	temp=spi_read(0x0a);
	temp=spi_read(0x00);

//	while(input(pin_calibracion));
//		delay_ms(50);
//	while(!input(pin_calibracion));
//	
////	lcd_putc("\fFin Calibracion...");
        do
        {
        caracter_x=getc();
        }while(caracter_x!='G');

	temp=spi_read(0xaa);//envio comando stop cal
	temp=spi_read(0x0b);
	temp=spi_read(0x00);

	temp=spi_read(0xaa);//envio comando saveconfig
	temp=spi_read(0x09);
	temp=spi_read(0x00);

}//fin calibracion
//





//void main()
//{
//float temperatura,direccion;
//int dato1, dato2,dato;
//int1 calibrar;
//
//temperatura=0;
////temperatura=lee_ieee();
////
////output_high(habilitador);
//output_low(pin_sync);
//delay_ms(1000);
////lcd_init();
////lcd_putc("iniciando...");
////delay_ms(1000);
//
////lcd_putc("\fConfig SPI...");
////delay_ms(500);
//set_tris_c(0b00010000);
//
//setup_spi(spi_master|SPI_L_TO_H|SPI_CLK_DIV_64|SPI_XMIT_L_TO_H);//configura spi
////lcd_putc("Hecho");
////delay_ms(500);
////output_low(habilitador);
////lcd_putc("\fcomunicando con:\n");
//output_high(pin_sync);
//delay_us(15);
//output_low(pin_sync);
//delay_us(15);
////Configuracion de los datos q envia la v2xe
////cada q se requieran datos
//dato=spi_read(0xaa);//byte de sincronizacion
//dato=spi_read(0x03);//comando
//dato=spi_read(0x03);//numero de datos=3
//dato=spi_read(0x07);//dato1=Temperatura
//dato=spi_read(0x05);//dato2=direccion
//dato=spi_read(0x09);//dato3=estado de calibracion
//dato=spi_read(0x00);//caracter de fin
//
//
//   dato=spi_read(0xaa);//pide info de v2xe
//   dato=spi_read(0x01);
//   dato=spi_read(0x00);
//
//while (dato!=0xaa)
//   dato=spi_read(0x00);
//
//while (dato!=0x00)
//   {
//
//      dato=spi_read(0x00);
//      printf(lcd_putc,"%c",dato);
//   }//while
//calibrar=0;
//if (calibrar)
//	calibracion();
//while(1)
//{
//   delay_ms(500);
//
//   dato=spi_read(0xaa);
//   dato=spi_read(0x04);//pide datos
//   dato=spi_read(0x00);
//   delay_ms(50);
//   while (dato!=0xaa)//Espera q la v2xe envie datos
//      dato=spi_read(0x00);
//
//   dato= spi_read(0);//lee id de comando
//   dato= spi_read(0);//lee n comp
//   dato1= spi_read(0);//lee id de dato
//   en_ieee[0]=spi_read(0x00);//lee dato1
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   temperatura=ieee_en_mic();//convierte de formato ieee a formato de microcip
//   dato2= spi_read(0);//lee id de dato 2
//   en_ieee[0]=spi_read(0x00);//lee dato2
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   direccion=ieee_en_mic();//convierte de formato ieee a formato de microcip
//   dato1=spi_read(0x00);//id dato 3
//   dato1=spi_read(0x00);
//   dato= spi_read(0);//lee caracter de fin
//   printf(lcd_putc,"\fTemp = %f\ndir = %f  %u",temperatura,direccion,dato1);
//}//while infinito
////output_high(habilitador);
//}//main
//
//
//
//Parte a cambiar en estacion_globo.c
//
//
//**********************************************//
//**Configuracion de los datos q envia la v2xe**//
//**cada q se requieran datos                 **//
//**********************************************//
void configura_v2xe(void)
{
spi_write(0xaa);//byte de sincronizacion
spi_write(0x03);//comando
spi_write(0x01);//numero de datos
spi_write(headingve);
spi_write(0x00);//caracter de fin  
delay_us(10);
//guarda conf.
spi_write(0xaa);
spi_write(0x09);
spi_write(0x00);

}
//
////*********************************//
////*****Lectura de sensor v2xe *****//
////*********************************//
//   output_low(habilitador);
//   delay_us(10);
//   setup_spi(spi_master|SPI_L_TO_H|SPI_CLK_DIV_64|SPI_XMIT_L_TO_H);//configura spi
//   dato_v2xe=spi_read(0xaa);
//   dato_v2xe=spi_read(0x04);//pide datos
//   dato_v2xe=spi_read(0x00);
//   //delay_ms(50);
//   while (dato_v2xe!=0xaa)//Espera q la v2xe envie datos
//      dato_v2xe=spi_read(0x00);
//
//   dato_v2xe= spi_read(0);//lee id de comando
//   dato_v2xe= spi_read(0);//lee n comp
//   
//   dato_v2xe= spi_read(0);//lee id de dato1
//   en_ieee[0]=spi_read(0x00);//lee dato1
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   x_calibrado=ieee_en_mic();//convierte de formato ieee a formato de microcip
//   dato_v2xe= spi_read(0);//lee id de dato 2
//   en_ieee[0]=spi_read(0x00);//lee dato2
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   y_calibrado=ieee_en_mic();//convierte de formato ieee a formato de microchip
//
//
//   dato_v2xe= spi_read(0);//lee id de dato3
//   en_ieee[0]=spi_read(0x00);//lee dato3
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   direccion=ieee_en_mic();//convierte de formato ieee a formato de microcip
//   dato_v2xe= spi_read(0);//lee id de dato 4
//   en_ieee[0]=spi_read(0x00);//lee dato4
//   en_ieee[1]=spi_read(0x00);
//   en_ieee[2]=spi_read(0x00);
//   en_ieee[3]=spi_read(0x00);
//   magnitud=ieee_en_mic();//convierte de formato ieee a formato de microchip
// 
//   dato_v2xe= spi_read(0);//lee caracter de fin
//
//
//
//
//
//
