import math
for phi in range(0,360):
    x=math.cos(math.radians(phi))
    y=math.sin(math.radians(phi))
    print(phi,x,y)