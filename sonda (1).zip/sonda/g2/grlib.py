"""Libreria para realizar graficas"""
from tkinter import *
import math
class grafica:
    def __init__(self,marco,
            #posicion,
            #escala,
            #tam,
            color='black',
            #offset,
            #nombre,
            ):
        #contenedor
        self.marco=marco,
        self.color=color,
        ##posicion inicial en px
        #self.x1=posicion[0]
        #self.y1=posicion[1]
        ##escala
        ##escala[0]=No. de unidades en X por cada 50px
        #self.xescala=escala[0]/50
        ##escala[1]=No. de unidades en Y por cada 25px
        #self.yescala=escala[1]/25
        ##tamaño en px
        #self.xmax=tam[0]
        #self.ymax=tam[1]
        ##color
        #self.color=color
        ##offset en unidades
        #self.xoffset=offset[0]
        #self.yoffset=offset[1]
        ##nombre de las variables a graficar
        #self.namex=nombre[0]
        #self.namey=nombre[1]

    def re_coorx(self,x):
        '''recalcula x'''
        x1=(x-self.xoffset)/self.xescala
        return x1
    def re_coory(self,y):
        '''recalcula y'''
        y1=self.ymax-((y-self.yoffset)/self.yescala)
        return y1
    
    def cpunto(self,x,y):
        '''coloca un punto en la grafica'''
        x=self.re_coorx(x)+self.x1
        y=self.re_coory(y)+self.y1
        self.marco.create_oval(x,y,x+1,y+1,outline=self.color)
    def cescalas(self):
        '''coloca la leyenda de una grafica'''
        tfuente=9
        margen=20
        self.marco.create_text(self.x1,self.y1+self.ymax+margen,text=self.namex)
        for x in range(0,self.xmax,50):
            self.marco.create_text(x+self.x1,self.y1+self.ymax+tfuente,text=str(x*self.xescala+self.xoffset))
        for y in range(self.y1+self.ymax,self.y1,-25):
            self.marco.create_text(self.x1-margen,y,text=str((self.ymax+self.y1-y)*self.yescala+self.yoffset))
    def ccuadricula(self):
        '''dibuja la cuadricula predefinida'''
        for x in range(self.x1,self.x1+self.xmax,50):
            self.marco.create_line(x,self.y1,x,self.ymax+self.y1)
        for y in range(self.y1+self.ymax,self.y1,-25):
            self.marco.create_line(self.x1,y,self.x1+self.xmax,y)
if __name__ == "__main__":
    print('hi!')
    root=Tk()
    marco=Canvas(root,width=600,height=500)
    marco.grid()
    marco.create_line(50,35,551,35)
    for x in range (50,551,100):
        marco.create_line(x,20,x,35)
        print(x)
    root.mainloop()